package compiler.phase.all;

import java.util.*;
import java.io.*;
import compiler.phase.Phase;
import compiler.phase.asmgen.ASM;
import compiler.phase.asmgen.ASM.AsmChunk;
import compiler.phase.asmgen.ASM.RegisterAndOffset;
import compiler.phase.regall.*;
import compiler.phase.asmgen.*;
//Class to generate epilouge, prolouge and output to file 
public class All extends Phase{
    public File f;
    public Vector<AsmChunk> koda;
    public AsmChunk data;
    public ASM.Register[] allRegisters;
    public All(String fileName, Vector<ASM.AsmChunk> koda, ASM.AsmChunk data, ASM.Register[] all){
        super("all");
        allRegisters = all;
        f = new File(fileName+".asm");
        this.koda = koda;
        this.data = data;
        try{
            f.createNewFile();
        }catch(Exception e){

        }
    }

    public Vector<ASM.Line> saveRegisters(){
        Vector<ASM.Line> x = new Vector<ASM.Line>();
        x.add(new ASM.Comment("Prologue"));
        for(int i = 1; i<32; i+=1){
            x.add(new RegisterAndOffset("sd", allRegisters[i], ASM.sp, -i*8));
            x.add(
                new RegisterAndOffset
                ("addi", 
                ASM.sp,
                ASM.zero,
                -8L
                )
            );  
        }
        return x;
    }
    public void updateTheThings(){
        for(AsmChunk trenutnaFunkcija : koda){
            //first do the prolog
            Vector<ASM.Line> x = new Vector<ASM.Line>();
            x = saveRegisters();
            x.addAll(trenutnaFunkcija.lines);
            ASM.AsmChunk z2 = new ASM.AsmChunk(x);
            trenutnaFunkcija = z2;
            //then do the epilouge
        }
        
    }

    public void printTheThing() throws Exception{
        FileWriter fw = new FileWriter(f);
        fw.append(data.toString());
        updateTheThings();
        for(AsmChunk x : koda){
            fw.append(x.toString());
        }
        System.out.println("Zakaj to ne dela");
        fw.close();
    }

}