/**
 * Assembly code
 * 
 * @author as40762@student.uni-lj.si
 */
package compiler.phase.asmgen;
