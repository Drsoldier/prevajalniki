/**
 * Abstract syntax.
 * 
 * @author bostjan.slivnik@fri.uni-lj.si
 */
package compiler.phase.abstr;
