/**
 * Linearization of intermediate code.
 * 
 * @author bostjan.slivnik@fri.uni-lj.si
 */
package compiler.phase.imclin;