/**
 * Infrastructure for generating logs of the individual compiler phases.
 * 
 * @author bostjan.slivnik@fri.uni-lj.si
 */
package compiler.common.logger;
