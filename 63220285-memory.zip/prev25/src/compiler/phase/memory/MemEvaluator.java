package compiler.phase.memory;

import java.util.*;

import compiler.phase.abstr.*;
import compiler.phase.abstr.AST.Nodes;
import compiler.phase.seman.*;
import compiler.phase.seman.NameResolver.*;
import compiler.phase.memory.*;
import compiler.phase.memory.Neki;
import compiler.common.report.*;


/**
 * Computing memory layout: stack frames and variable accesses.
 * 
 * @author bostjan.slivnik@fri.uni-lj.si
 */
public class MemEvaluator implements AST.FullVisitor<Object, Neki> {
    public static SizeEvaluator sizeEval = new SizeEvaluator();
    //public static Neki neki;
    
    @Override
    public Object visit(AST.VarDefn varDefn, Neki arg) {
        if(arg.depth ==0){
            long size = SemAn.ofType.get(varDefn).accept(sizeEval, null);
            return Memory.accesses.put(varDefn, new MEM.AbsAccess(size, new MEM.Label(varDefn.name)));
        }
        var size = SemAn.ofType.get(varDefn).accept(sizeEval, null);
        return Memory.accesses.put(varDefn, new MEM.RelAccess(size, arg.offset-size, arg.depth-1));
        
    }

    
    
    
    @Override
	public TYP.Type visit(Nodes<? extends AST.Node> nodes, Neki arg) {
        arg = new Neki();
        for (final AST.Node node : nodes){
			node.accept(this, arg);
		}

		
		return null;
	}


    @Override
    public Object visit(AST.DefFunDefn defFunDefn, Neki arg) {
        var label = new MEM.Label(defFunDefn.name);
        //var size = Memory.accesses.get(defFunDefn).size;
        var curDepth = arg.depth+1;
        arg.depth+=1;
        var oldSize = arg.size;
        defFunDefn.pars.accept(this, arg);
        var curSize = arg.size;
        arg.size = oldSize;
        var curOffset = arg.offset;
        MEM.Frame access = new MEM.Frame(label, curDepth, 0, curSize, curSize);
        //var neki = Memory.accesses.get(defFunDefn);
        //Report.info("null"+neki);
        Memory.frames.put(defFunDefn, access);
        return access;
    }
    @Override
    public Object visit(AST.ExtFunDefn extFunDefn, Neki arg) {
        var label = new MEM.Label(extFunDefn.name);
        //var size = Memory.accesses.get(defFunDefn).size;
        var curDepth = arg.depth+1;
        arg.depth+=1;
        var oldSize = arg.size;
        extFunDefn.pars.accept(this, arg);
        var curSize = arg.size;
        arg.size = oldSize;
        var curOffset = arg.offset;
        return null;
    }

    @Override
    public Object visit(AST.ParDefn parDefn, Neki arg) {
        
        var size = SemAn.ofType.get(parDefn);
        long l = size.accept(sizeEval, null) + 1l;
        l = size.accept(sizeEval, null) + 1l;
        

       if(size instanceof TYP.RecType){
            Neki n = new Neki(arg.depth, l, 0);
            parDefn.type.accept(this, n);
            arg.offset = n.size;
        }else{
            arg.offset += l;
            //naprej
            parDefn.type.accept(this, arg);
        }
       
        parDefn.type.accept(this, arg);

        var t = new MEM.RelAccess(l, arg.offset, arg.depth);
        return Memory.accesses.put(parDefn, t);
    }

    @Override
    public Object visit(AST.CompDefn compDefn, Neki arg) {
        TYP.Type b = SemAn.ofType.get(compDefn);
        long size = b.accept(sizeEval, null);
        
        var access = new MEM.RelAccess(size, arg.offset, -1);
        if(b instanceof TYP.RecType){
            Neki n = new Neki(arg.depth, size, 0);
            compDefn.type.accept(this, n);
            arg.offset = n.size;
        }else{
            arg.offset += size;
            //naprej
            compDefn.type.accept(this, arg);
        }
        
        return Memory.accesses.put(compDefn, access);
    }
    
    @Override
    public Object visit(AST.AtomExpr atomExpr, Neki arg) {
        switch (atomExpr.type) {
        case STR:
            var size = (long)(atomExpr.value.length() + 1);
            var access2 = new MEM.Temp();
            break;
        default:
            break;
        }
        return null;
    }
}