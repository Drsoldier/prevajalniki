/**
 * Memory (stack frames and variables accesses).
 * 
 * @author bostjan.slivnik@fri.uni-lj.si
 */
package compiler.phase.memory;