/**
 * Infrastructure for generating reports.
 * 
 * @author bostjan.slivnik@fri.uni-lj.si
 */
package compiler.common.report;
